802.1x Credential Extraction Tool
Copyright (c) 2018-2019 devicelocksmith.com
Version: 1.04 windows 386

Set Internet (ONT) interface MAC address to C0:89:AB:07:13:71
Start wpa_supplicant with the following command. Replace paths and interface name with correct values.

/sbin/wpa_supplicant -s -B -Dwired -ieth0 -c/etc/wpa_supplicant.conf &

